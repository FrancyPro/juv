/**
 * This package contains code for Events,
 * all of this was originally coded by
 * Eric Golde and implemented by Felix 
 * Eckert.
 * */
package de.felixeckert.medaclient.events;