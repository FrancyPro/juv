package de.felixeckert.medaclient.events.imp;

import de.felixeckert.medaclient.events.Event;

public class RenderEvent extends Event {

}
